import json
import boto3
import os

sns_client = boto3.client('sns')
dynamodb = boto3.resource('dynamodb')

SNS_TOPIC_ARN = os.environ['SNS_TOPIC_ARN']
DYNAMODB_TABLE = os.environ['DYNAMODB_TABLE']

def lambda_handler(event, context):
    print("Received event:", event)

    # Parse body
    if 'body' in event:
        body = json.loads(event['body'])  # For API Gateway
    else:
        body = event  # For direct invocation (testing)

    name = body.get('name')
    email = body.get('email')

    if not name or not email:
        return {
            'statusCode': 400,
            'body': json.dumps('Missing name or email')
        }

    # Store in DynamoDB
    table = dynamodb.Table(DYNAMODB_TABLE)
    table.put_item(Item={
        'email': email,
        'name': name
    })

    # Send SNS notification
    message = f"New NeoCloud Event Registration:\nName: {name}\nEmail: {email}"
    sns_client.publish(
        TopicArn=SNS_TOPIC_ARN,
        Message=message,
        Subject="New Event Registration"
    )

    return {
    'statusCode': 200,
    'headers': {
        'Access-Control-Allow-Origin': '*',
        'Content-Type': 'application/json'
    },
    'body': json.dumps({'message': 'Registration successful!'})
}


